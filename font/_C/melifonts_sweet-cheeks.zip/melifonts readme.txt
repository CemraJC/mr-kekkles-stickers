Thank you for downloading! I hope you enjoy your new font. Please use it for your own personal projects only. If you would like to use this font for anything commercial, please send me an email and we can work out a license. Also, if you make anything really cool with this font, I'd love to see it!

Check out my other free fonts:
http://www.fontspace.com/melifonts

Check out my licensed fonts:
http://new.myfonts.com/foundry/melifonts

Are there are any accented/special characters not included in this font that you would like me to add? Send me an email (meli327@hotmail.com) and I will respond to any reasonable request for additional characters with an updated version of this font.

This typeface (c) 2012 by Melinda C. Jeffs. Feel free to distribute and share this font, just make sure you include all the files from the original download. And don't make any modifications to my font. No one likes a jerk.

________________
created by melifonts
Melinda C. Jeffs
meli327@hotmail.com